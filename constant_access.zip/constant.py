PI=3.14
gravity=9.8